package com.example.mycurrentlocation;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {
    String email;
    Button button_location;
    TextView textView_location;
    LocationManager locationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);





    }
    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    public void something(View view){
        TextView email = findViewById(R.id.txtEmail);
        TextView password = findViewById(R.id.txtPwd);

        System.out.println(email.getText());

        System.out.println(password.getText());

        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(StandardCharsets.UTF_8.encode("asd"));
            String hashedPass = String.format("%032x", new BigInteger(1, md5.digest()));
            String result = login(email.getText().toString(),hashedPass);
            System.out.println(result);
            if (true){
                String data = login("asd","|dsa");
                if (true){
                    this.email = email.getText().toString();
                    setContentView(R.layout.activity_main);
                    StrictMode.ThreadPolicy a = new StrictMode.ThreadPolicy.Builder().permitAll().build();

                    StrictMode.setThreadPolicy(a);
                    textView_location = findViewById(R.id.text_location);
                    button_location = findViewById(R.id.button_location);
                    //Runtime permissions
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                            != PackageManager.PERMISSION_GRANTED){
                        ActivityCompat.requestPermissions(MainActivity.this,new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION
                        },100);
                    }


                    button_location.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            //create method
                            getLocation();

                        }
                    });
                }
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {
                        getLocation();
                        handler.postDelayed(this, 1200); //now is every 2 minutes
                    }
                }, 1200); //Every 120000 ms (2 minutes)
            }

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        //
//        setContentView(R.layout.activity_main);
    }
    private String updateData(String lat, String lon){
        StringBuilder a = new StringBuilder();
        try {
            URL uri = new URL("http://example.comcom/checkPass.php?lat=" + lat + "&lon=" + lon+" &email=" + email);
            URLConnection ec = uri.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    ec.getInputStream(), "UTF-8"));
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                a.append(inputLine);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return a.toString();
    }



    private String login(String email, String password){
        StringBuilder a = new StringBuilder();
        try {
            URL uri = new URL("http://example.com/checkPass.php?email=" + email + "&password=" + password);
            URLConnection ec = uri.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    ec.getInputStream(), "UTF-8"));
            String inputLine;
            while ((inputLine = in.readLine()) != null)
                a.append(inputLine);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return a.toString();
    }


    @SuppressLint("MissingPermission")
    private void getLocation() {

        try {
            locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,5,MainActivity.this);

        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onLocationChanged(Location location) {
        Toast.makeText(this, ""+location.getLatitude()+","+location.getLongitude(), Toast.LENGTH_SHORT).show();
        try {
            Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);

            textView_location.setText(address);
            updateData(""+location.getLatitude(),""+location.getLongitude());
            System.out.println("asd");
        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
